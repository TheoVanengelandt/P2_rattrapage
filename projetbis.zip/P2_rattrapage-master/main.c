#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h> 	//Ne pas oublier d'inclure le fichier time.h
#include "Prototypes.h"


int main (int argc, char *argv[])
{
	int TypeDeFond;

	if(argv[0]=="stat")
	{
		system("./historique/log");
	}
	else
	{
		TypeDeFond=0; //rand()%3; //renvoi une valeur pseudo-aléatoire (0, 1 ou 2), correspondant au type d'ecrande veille a exec.
    		pid_t pid_fils;
		char *ParamList[] = {"test", NULL};

	    	pid_fils = fork();
		printf("pid = %d\n\n", pid_fils);

		if (pid_fils ==  0)	// child process
		{
			printf("processus fils\n");

		    	if (TypeDeFond == 0)
			{
				printf("Program static\n");
				execv("/home/julien/Bureau/P2_rattrapage-master/test", ParamList);
		    	}
		   	else if (TypeDeFond == 1)
			{
				printf("test2");
				system("./dynamic");
		    	}
		    	else if (TypeDeFond == 2)
			{
				printf("test3");
				system("./interractif");
	   		}
			
		}
	    	else if (pid_fils > 0)	// parent process
		{
			perror("wait :");
		}
	    	else	// fork failed
		{
        		printf("fork() failed!\n");
			perror("fork");
	    	}

		quit();
		printf("Le processus ne c'est pas arrêté"); //vérifie l'arrêt du processus
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AfficheLog.h"
#define TAILLE_MAX 1000

void main(int argc, char *argv[])
{
	int stat=0, dyn=0, interactif=0, total=0; // pour les stats
	char chaine[TAILLE_MAX];

	FILE* f=NULL;
	f=fopen("log.txt","r");
	printf("\n");

	if (strcmp(argv[1],"Complet")==0)
	{		
		if(f!=NULL)
		{	
			while(fgets(chaine, TAILLE_MAX, f)!= NULL)
			{				
				printf("%s",chaine);
			}
		}
	}
	else
	{
		statistique(&stat, &dyn, &interactif, &total);
		//On test les valeurs recupérées dans lea focntion statistique()
		//printf("s=%d, d=%d, i=%d, tt=%d", stat, dyn, interactif, total);

		if (strcmp(argv[1],"Static")==0) // si on a bien écrit statique
		{
			printf("\nNombres de lancement du statique: %d\n", stat);
			total = (100*stat)/total;
			printf("Ce qui représente %d pourcents des fonds utilisés pour le moment.\n",total);
		}
		else if (strcmp(argv[1],"Dynam")==0) // si on a bien écrit dynamique
		{
			printf("\nNombres de lancement du dynamique: %d\n", dyn);
			total = (100*dyn)/total;
			printf("Ce qui représente %d pourcents des fonds utilisés pour le moment.\n",total);
		}
		else if (strcmp(argv[1],"Inter")==0) //si on a bien écrit interactif
		{	
			printf("\nNombres de lancement du interactif: %d\n", interactif);	
			total = (100*interactif)/total;
			printf("Ce qui représente %d pourcents des fonds utilisés pour le moment.\n",total);
		}
 	}
	fclose(f);
	exit(EXIT_SUCCESS);
	printf("\nLe programme ne c'est pas fermé correctement");
}




void statistique(int *stat, int *dyn, int *interactif, int *total) // fonction pour le calcul des stats
{
	int ent; //valeurs entieres pour la recup du types de fond d'écran
	char chaine[TAILLE_MAX]= "";// chaine de lecture
	char chaineAnex[TAILLE_MAX] = "";// chaine de remplacemant après filtrage des dièses
	char *token; //division de la chaine
	const char t[100]=" ";// sépare en espace
	const char s='#'; // filtre les #

	FILE* f=NULL;
	f=fopen("log.txt","r"); 
	
	if (f != NULL)
	{
		while(fgets(chaine, TAILLE_MAX, f)!= NULL) //tant qu'on atteint pas la fin du doc texte, on place la chaine de lecture dans chaine
		{	
			if (!strchr(chaine, s)) //fitrage des "#"
              		{
				strcpy(chaineAnex,chaine);
				token = strtok(chaineAnex, t); // découpage de la chaine
				while(token != NULL)
				{
					if (strlen(token)<=2) //si nous avons une chaine inférieur ou égal à 2, c'est qu'elle contient le type de fond
					{ 
						ent = atoi(token); //chaine en entier
					}
					token = strtok(NULL, t);

					switch (ent)
					{
						case 1 :
							*stat +=1;
							*total +=1;
							break;
						case 2 :
							*dyn +=1;
							*total +=1;
							break;
						case 3 :
							*interactif +=1;
							*total +=1;
							break;
					}
				}
			}
		}
	}
	fclose(f);	//ferme le fichier
}

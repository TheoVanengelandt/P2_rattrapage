# P2_rattrapage
GitHub_du_rattrapage

Je vous propose de travailler directement à partir de GitHub!
Comme ça on va dire que tout ce passe ici et pas chacun dans son coin.
il sera nécéssaire de suivre régulièrement les nouveaux postes.

Hésitez pas à ajouter ici,
voila!
PS: les messages se feront ici pour plus de visibilitée (exclusivement travail).

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AfficheLog.h"


void main(int argc, char *argv[])
{
    	system("clear");

	if(argc>=2 && strcmp(argv[1],"Complet")==0)
	{
		printf("histo Complet\n");
	}
	else if(argc>=2 && strcmp(argv[1],"Static")==0)
	{
		printf("histo 1\n");
	}
	else if(argc>=2 && strcmp(argv[1],"Dynam")==0)
	{
		printf("histo 2\n");
	}
	else if(argc>=2 && strcmp(argv[1],"interact")==0)
	{
		printf("histo 3\n");
	}
	else
	{
		printf("erreur dans les paramètres\n\n");
		quit();
	}
	quit();
	printf("Le programme ne c'est pas fermé correctement");
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AfficheLog.h"
#define TAILLE_MAX 1000

void main(int argc, char *argv[])
{
	int stat=0, dyn=0, interactif=0, total=0; // pour les stats
	char chaine[TAILLE_MAX];

	FILE* f=NULL;
	f=fopen("log.txt","r");
	printf("\n");

	if (strcmp(argv[1],"Complet")==0)
	{		
		if(f!=NULL)
		{	
			while(fgets(chaine, TAILLE_MAX, f)!= NULL)
			{				
				printf("%s",chaine);
			}
		}
	}
	else
	{
		statistique(&stat, &dyn, &interactif, &total);
		//On test les valeurs recupérées dans lea focntion statistique()
		//printf("s=%d, d=%d, i=%d, tt=%d", stat, dyn, interactif, total);

		if (strcmp(argv[1],"Static")==0) // si on a bien écrit statique
		{
			printf("\nNombres de lancement du statique: %d\n", stat);
			total = (100*stat)/total;
			printf("Ce qui représente %d pourcents des fonds utilisés pour le moment.\n",total);
		}
		else if (strcmp(argv[1],"Dynam")==0) // si on a bien écrit dynamique
		{
			printf("\nNombres de lancement du dynamique: %d\n", dyn);
			total = (100*dyn)/total;
			printf("Ce qui représente %d pourcents des fonds utilisés pour le moment.\n",total);
		}
		else if (strcmp(argv[1],"Inter")==0) //si on a bien écrit interactif
		{	
			printf("\nNombres de lancement du interactif: %d\n", interactif);	
			total = (100*interactif)/total;
			printf("Ce qui représente %d pourcents des fonds utilisés pour le moment.\n",total);
		}
 	}
	fclose(f);
	quit();
	printf("\nLe programme ne c'est pas fermé correctement");
}

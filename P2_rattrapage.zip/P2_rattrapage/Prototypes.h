#ifndef PROTOTYPES_H_INCLUDED
#define PROTOTYPES_H_INCLUDED

int quit();
int testASCII();


int EcranStatic(int** Ecran);

void Type1(int i);
void Type2(int i,int j,int l);


enum stat
{
	c,
	s,
	d,
	i,
};


void histo1 (char* nomFichier, int type_de_fichier);

#endif // PROTOTYPES_H_INCLUDED

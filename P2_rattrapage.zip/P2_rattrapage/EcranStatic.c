#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include "PrototipeStatic.h"


int main(int argc, char *argv[])
{
	if(argc >= 2)
	{
		Ttab* tab = NULL;

		affecter(&tab, argv[1]);
		Affichetableau(&tab);
		return 0;
	}

	else
	{
		return 0;
	}
}

#include <stdio.h>
#include <stdlib.h>
#include "Prototypes.h"

int quit()
{
    //Met fin au programme.
    exit(EXIT_SUCCESS);
}

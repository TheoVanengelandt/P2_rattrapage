#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AfficheLog.h" //pour l'appel de fonction statistique
#define TAILLE_MAX 1000

void statistique(int *stat, int *dyn, int *interactif, int *total) // fonction pour le calcul des stats
{
	int ent; //valeurs entieres pour la recup du types de fond d'écran
	char chaine[TAILLE_MAX]= "";// chaine de lecture
	char chaineAnex[TAILLE_MAX] = "";// chaine de remplacemant après filtrage des dièses
	char *token; //division de la chaine
	const char t[100]=" ";// sépare en espace
	const char s='#'; // filtre les #

	FILE* f=NULL;
	f=fopen("log.txt","r"); 
	
	if (f != NULL)
	{
		while(fgets(chaine, TAILLE_MAX, f)!= NULL) //tant qu'on atteint pas la fin du doc texte, on place la chaine de lecture dans chaine
		{	
			if (!strchr(chaine, s)) //fitrage des "#"
              		{
				strcpy(chaineAnex,chaine);
				token = strtok(chaineAnex, t); // découpage de la chaine
				while(token != NULL)
				{
					if (strlen(token)<=2) //si nous avons une chaine inférieur ou égal à 2, c'est qu'elle contient le type de fond
					{ 
						ent = atoi(token); //chaine en entier
					}
					token = strtok(NULL, t);

					switch (ent)
					{
						case 1 :
							*stat +=1;
							*total +=1;
							break;
						case 2 :
							*dyn +=1;
							*total +=1;
							break;
						case 3 :
							*interactif +=1;
							*total +=1;
							break;
					}
				}
			}
		}
	}
	fclose(f);	//ferme le fichier
}

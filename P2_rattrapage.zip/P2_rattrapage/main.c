#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h> 	//Ne pas oublier d'inclure le fichier time.h
#include <sys/ioctl.h>
#include "Prototypes.h"


int main (int argc, char *argv[])
{
	int TypeDeFond;

	if(argc>=2 && strcmp(argv[1],"-stat")==0)
	{
		int mode;
		/* First argument is executable name only */
 		printf("\n exe name=%s\n", argv[1]); //argv[1]== "-stat"

		printf("Quel type d'affichage choississez-vous?\n \n");
		printf("- HistoriqueComplet : 0\n- Historique écran statique : 1\n- Historique écran dynamique : 2\n- Historique écran interactif : 3\n");
		scanf("%d", &mode);


		switch (mode)
		{
			case 0:
				//Utilisation de la commande système sort -n afin de trier le fichier et l'afficher
				break;
			case 1:
				
				break;
			case 2:
				
				break;
			case 3:
				
				break;
			default:
				printf("Le mode sélectionné n'est pas disponnible.");
				break;

		}
	    	quit();
		printf("Le processus ne c'est pas arrêté"); //vérifie l'arrêt du processus
	}

	else
	{
		srand (time (NULL));
		TypeDeFond= rand()%3; //renvoi une valeur pseudo-aléatoire (0, 1 ou 2), correspondant au type d'ecrande veille a exec.

		struct winsize w;
		ioctl(0, TIOCGWINSZ, &w);

    		pid_t pid_fils;

	    	pid_fils = fork();
		//printf("pid = %d\n\n", pid_fils);

		if (pid_fils == -1)
		{
			printf("Erreur de création du nouveau processus!");
			quit();
		}
		else if (pid_fils ==  0)	// child process
		{
			//printf("processus fils\n");

		    	if (TypeDeFond == 0)
			{
				//printf("Program static\n");
				    char *nomFichier;
				    int choix = rand()%5;

				    switch(choix)
				    {
					case 0:
					    	nomFichier = "EXIASAVER1_PBM/ex1.pbm";
					    	break;
					case 1:
					    	nomFichier = "EXIASAVER1_PBM/ex2.pbm";
					    	break;
					case 2:
						nomFichier = "EXIASAVER1_PBM/ex3.pbm";
					    	break;
					case 3:
						nomFichier = "EXIASAVER1_PBM/ex4.pbm";
						break;
					case 4:
						nomFichier = "EXIASAVER1_PBM/ex5.pbm";
						break;
				    }
				histo1(nomFichier, TypeDeFond);


				char *ParamList[] = {"test", nomFichier, NULL};
				execv("/home/theo/Bureau/P2_rattrapage/test", ParamList);
		    	}
		   	else if (TypeDeFond == 1)
			{
				char posInitialDyn[20];

				int posX = rand()%w.ws_col;
				int posY = rand()%w.ws_row;
					
				sprintf(posInitialDyn, "%dx%d", posX, posY);
				
				histo1(posInitialDyn, TypeDeFond);
				printf("position Initial Dynamique = %s\n", posInitialDyn);

				//char *ParamList[] = {"EcranDyn", posInitialDyn, NULL};
				//execv("/home/theo/Bureau/P2_rattrapage/EcranDyn", ParamList);
		    	}
		    	else
			{
				char posInitialInteract[20];

				int posX = rand()%w.ws_col;
				int posY = rand()%w.ws_row;
					
				sprintf(posInitialInteract, "%dx%d", posX, posY);
				
				histo1(posInitialInteract, TypeDeFond);
				printf("position Initial Interactif = %s\n", posInitialInteract);

				//char *ParamList[] = {"EcranInteract", posInitialInteract, NULL};
				//execv("/home/theo/Bureau/P2_rattrapage/EcranInteract", ParamList);
	   		}
		}
	    	else	// parent process
		{
			//waitpid(pid_fils, NULL, 0);
			wait(NULL);
			printf("le programme c'est finis correctement  ^^\n\n");
		}

	    	quit();
		printf("Le processus ne c'est pas arrêté"); //vérifie l'arrêt du processus
	}
}

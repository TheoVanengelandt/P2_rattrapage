#ifndef PROTOTIPESTATIC_H_INCLUDED
#define PROTOTIPESTATIC_H_INCLUDED

void main(int argc, char *argv[]);	//la fonction qui permet l'affichage des statistiques
int quit();	//La fonction exit()



#endif // PROTOTIPESTATIC_H_INCLUDED

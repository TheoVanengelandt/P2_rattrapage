#ifndef PROTOTIPESTATIC_H_INCLUDED
#define PROTOTIPESTATIC_H_INCLUDED

void main(int argc, char *argv[]);	//la fonction qui permet l'affichage des statistiques
int quit();	//La fonction exit()

void statistique(int* stat, int* dyn, int* interactif, int* total);  // pour les logs et stats


#endif // PROTOTIPESTATIC_H_INCLUDED

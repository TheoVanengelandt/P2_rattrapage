#ifndef DYNAMIQUE_H_INCLUDED
#define DYNAMIQUE_H_INCLUDED

void choixFormatAleatoire();
void initialiserDynamique(FILE* fichierPbm);
void actualisationHeure(int n);
void lireFichierPbmDynamique(FILE* fichierPbm);

#endif

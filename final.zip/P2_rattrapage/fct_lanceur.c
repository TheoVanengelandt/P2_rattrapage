#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h> 	//Ne pas oublier d'inclure le fichier time.h
#include <sys/ioctl.h>
#include "Prototypes.h"


void histo1(char* nomFichier, int type_de_fichier)
{	
	FILE* f;	// Création d'un poiteur sur fichier f

	char data[20];
	time_t now = time(NULL);
	strftime(data, sizeof(data), /*"%d/%m/%Y*/"%Y/%m/%d %H:%M:%S", localtime(&now));	// Le temps sous la forme "jour/mois/année heure:minutes:secondes" est stocké dans data sous forme de chaîne de caractères

	f=fopen("log.txt","a");	//Ouverture du fichier log.txt en se postionnant à sa fin ou crétion du fichier si il n'existe pas

	fprintf(f, "%s ", data);	//Impression dans le fichier du temps
	fprintf(f, "%d ", (type_de_fichier+1));	//Impression du type d'écran

	//Si il s'agit d'un fichier de niveau 2 ou 3, le nom du fichier est en fait les coordonnees initiales, du type XxY (exemple: 10x22)
	fprintf(f,"%s\n", nomFichier);	//print le nom du fichier ou la pos initiale

	fclose(f);	//ferme le fichier

}

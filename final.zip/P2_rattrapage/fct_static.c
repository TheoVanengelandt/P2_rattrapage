#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include "PrototipeStatic.h"
#define TAILLE_MAX 1000

void affecter(Ttab** tab, char* nomDuFichier)
{
    FILE* fichier = NULL;

    char chaine[TAILLE_MAX] = "";
    char chaineAnex[TAILLE_MAX] = "";
    const char t='#'; //Constantes permettant le filtrage des caractère du pbm
    const char m='P'; //Constantes permettant le filtrage des caractère du pbm

    int ent,y =0;    //valeur sortie du pbm et ajouté au tableau
    int tb[2] = {0};
    int i=0, j=0, l=0, c=0, repetition =0;

    const char s[100] = " ";//Pour mettre le nombre d'espaces
    char *token; //chaine temporaire pour diviser

    fichier = fopen(nomDuFichier, "r");
    initialisationStruct(tab);

    if (fichier != NULL)
    {
        while(fgets(chaine, TAILLE_MAX, fichier)!= NULL)
        {
            if (!strchr(chaine, m))
            {
                strcpy(chaineAnex,chaine);

                if (!strchr(chaine, t))
                {
                    strcpy(chaineAnex,chaine);
                    token = strtok(chaineAnex, s);

                    while(token!=NULL)
                    {
                        ent = atoi(token);
                        token = strtok(NULL, s);

                        if (ent>1)
                        {
                            tb[y]=ent;
                            y++;
                        }

                        l=tb[1];
                        c=tb[0];

                        if(l!=0 && c!=0 && ent<2)
                        {
                            if(repetition == 0)
                            {
                                allocation(tab, c, l);
                                (*tab)->colonnes = c;
                                (*tab)->lignes = l;
                                //printf("\n%d %d \n",l,c); //permet d'afficher les lignes et colonnes récupérée
                                repetition =1;
                            }

                            switch(ent)
                            {
                                case 1:
                                    ent = 219;
                                    break;

                                case 0:
                                    ent = 32;
                                    break;
                            }


                            (*tab)->tableau[i][j] = ent;

                            //printf("%c", (*tab)->tableau[i][j]); //Permet de tester la récupération ds caractères dans le tableauprintf("%c", (*tab)->tableau[i][j]);

                            if(j<=l-1)
                            {
                                if(i==c-1)
                                {
                                    //printf("<-i=%d et j=%d", i, j);
                                    j++;
                                    i=0;
                                    //printf("\n");

                                }
                                else
                                {
                                    //printf("<-i=%d et j=%d", i, j);
                                    i++;
                                }
                            }
                        }
                    }
                }
            }
        }
        //permet de virifé le schémas récupéré dans le tableau
/*
        for(int k=0; k<=(c-1); k++)
        {
            for(int m=0; m<=(l); m++)
            {
                printf("%c", (*tab)->tableau[m][k]); //Permet de tester la récupération ds caractères dans le tableauprintf("%c", (*tab)->tableau[i][j]);
            }

            printf("\n");
        }
*/
        fclose(fichier);
    }
    else
    {
        // On affiche un message d'erreur si on veut
        printf("\n Impossible d'ouvrir le fichier test.txt\n");
    }
}


int Affichetableau(Ttab** tab)
{

    int nbrColonnes = (*tab)->colonnes;
    int nbrLignes = (*tab)->lignes;
    int debutX = nbrColonnes;
    int debutY = nbrLignes;

    struct winsize w;
    ioctl(0, TIOCGWINSZ, &w);

    int valeur, a, b;

    PosIniTableauCentre(&debutX, &debutY);    //position initial du tableau en X et Y

    system("clear");

    //permet de verifier les valeurs obtenues
    //printf("\n x = %d, y = %d, nbrLigne= %d, nbrColonnes = %d  \n", debutX, debutY, nbrLignes, nbrColonnes);

	for(int j=0; j<w.ws_row; j++)
	{
		for(int i=0; i<(nbrColonnes+debutX); i++)
		{
			valeur = 0;
			//printf("a=%d et b=%d ", i, j);
			if(debutX<=i && i<(nbrColonnes+debutX))
			{
				if(debutY<=j && j<(nbrLignes+debutY))
				{
                    			a = i-debutX;
                    			b = j-debutY;
                    			valeur = (*tab)->tableau[a][b];
                		}
            		}
            		printf("%c ", valeur);
        	}
        	printf("\n");
    	}
	int entreeClavier;
	while(1)
	{
		entreeClavier=getchar();
		if(entreeClavier!=0)
		{
			system("clear");
			return EXIT_SUCCESS;
		}
	}
}


void allocation(Ttab** LeTab, int taille1, int taille2)
{
    if((*LeTab) == NULL)
    {
        exit(EXIT_FAILURE);
    }


    (*LeTab)->tableau = malloc(taille1*sizeof(int*)); //on alloue la premiere dimension

    if((*LeTab)->tableau == NULL)
    {
        exit(EXIT_FAILURE);
    }


    for(int k=0; k<taille1; k++)
    {
        (*LeTab)->tableau[k] = malloc(taille2*sizeof(int*)); //on alloue la second dimension du tableau


        if((*LeTab)->tableau[k] == NULL)
        {
            for(k = k-1; k >=0; k--)//on parcourt la boucle dans l'ordre inverse
            {
                 free((*LeTab)->tableau[k]);   //Libération de la deuxième dimension
            }

            free((*LeTab)->tableau);   //Libération de la première dimension

            (*LeTab)->tableau = NULL; //Par mesure de securité

            exit(EXIT_FAILURE);
        }
    }
}



void initialisationStruct(Ttab** LeTab)
{
    (*LeTab) = malloc(sizeof(*LeTab));

    if((*LeTab) == NULL)
    {
        exit(EXIT_FAILURE);
    }

    (*LeTab)->colonnes = 0;
    (*LeTab)->lignes = 0;

    (*LeTab)->tableau = 0;
}



void PosIniTableauCentre(int* Colonnetab, int* Lignetab)
{
    struct winsize w;
    ioctl(0, TIOCGWINSZ, &w);


    *Colonnetab = (w.ws_col - *Colonnetab)/2 ;
    *Lignetab = (w.ws_row - *Lignetab)/2 ;

    //printf("%d %d\n \n", Colonnetab, Lignetab);

}



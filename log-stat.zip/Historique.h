void histo1(char* nomFichier);
void histo2(int abs, int ord);
void histo3(int abs, int ord);
void afficherLog();
void statistique(int stat, int dyn, int interactif, int total); // pour les logs et stats



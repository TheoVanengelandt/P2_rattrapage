#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Historique.h" //pour l'appel de fonction statistique
#define TAILLE_MAX 1000

int main(int argc, char *argv[])
{
	int stat=0 ,dyn=0 ,interactif=0 ,total=0; // pour les stats
	char saisie[TAILLE_MAX];// pour la recup de la saisie du scanf
	char chstat[]="statique" ,chdyn[]="dynamique" ,chint[]="interactif";//pour la comparaison avec la saisie
	char chaine[TAILLE_MAX];

	FILE* f=NULL;
	f=fopen("log.txt","");             // a enlever apres


	if (argv[1]=="complet"){		
																																																																																																																																																																																																																																																																																																																																																							
		if (f != NULL)
		{
			while(fgets(chaine, TAILLE_MAX, f)!= NULL)
			{				
				printf("%s\n",chaine);
			}
		}
	}
	else //if (argv[1] == "stat") ------------------------- ATTTTENTION test: enleve les // quand tu auras finies
	{
		printf("entrez le type d'écran que vous souhaitez voir\n");
		scanf("%s", saisie);
		printf("vous avez choisi le %s\n", saisie);
		statistique(stat, dyn, interactif, total);
		if (strcmp(saisie,chstat)==0) // si on a bien écrit statique
		{
			printf("Nombres de lancement du statique: %d\n", stat);
			total = (total*stat)/100;
			printf("soit %d pourcents\n",total);
		}
		else if (strcmp(saisie,chdyn)==0) // si on a bien écrit dynamique
		{
			printf("Nombres de lancement du dynamique: %d\n", dyn);
			total = (total*dyn)/100;
			printf("soit %d pourcents\n",total);
		}
		else if (strcmp(saisie,chint)==0) //si on a bien écrit interactif
		{	
			printf("Nombres de lancement du interactif: %d\n", interactif);	
			total = (total*interactif)/100;
			printf("soit %d pourcents\n",total);
		}
 	}
	//fclose(f);
}
